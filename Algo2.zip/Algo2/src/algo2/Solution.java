/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algo2;

public class Solution {
     public int[] solution(int[] A, int[] B)
     { int []T=new int[A.length];
         
      for (int i=0;i<A.length;i++)
        {if (A[i]<4)
            T[i]=A[i]%(2*B[i]);
        else if (A[i]==4)
            T[i]=(A[i]+1)%(2*B[i]); 
        else 
            T[i]=((A[i]*2)-2)%(2*B[i]); 
        }
         return T;
     }


    
}
