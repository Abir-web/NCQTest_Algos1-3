/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algo2;

import java.util.Scanner;
/**
 *
 * @author hp
 */
public class Algo2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
          Scanner my_scan=new Scanner(System.in);
          int [] A; int [] B;
        
         System.out.println("Veuillez saisir la taille L des deux tableau A et B : ");        
         int L=my_scan.nextInt();
         
        while(L<=0 || L>50000)
        { System.out.println("Erreur !\nL doit etre entre [1..50000]");
            L=my_scan.nextInt();       
        }
        
        A=new int[L];
        B=new int[L];
        
        for (int i=0;i<L;i++)
        {System.out.println("A["+(i+1)+"]:");
         A[i]=my_scan.nextInt();
                while (A[i]<1 || A[i]>L) 
                {System.out.println("Erreur !\nA[i] doit être entre [1..L]");
                    A[i]=my_scan.nextInt();
                }
        }
 
                for (int i=0;i<L;i++)
            {System.out.println("B["+(i+1)+"]:");
             B[i]=my_scan.nextInt();
                while (A[i]<1 || A[i]>30) 
                {System.out.println("Erreur !\nB[i] doit être entre [1..30]");
                    B[i]=my_scan.nextInt();
                }
        }
 
        int [] res;
        
        Solution sol=new Solution();
        res=sol.solution(A, B);
        
            System.out.print("[");
        for (int i=0;i<res.length;i++)
        {if (i<res.length-1)// juste pour un bon affichage
            System.out.print(res[i]+" , ");
            else 
            System.out.print(res[i]);
        }
            System.out.print("]");
    }
    
}
