/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algo1;

import java.util.Scanner;

/**
 *
 * @author hp
 */
public class Algo1 {
    
    
    public static void main(String[] args) {
        
   int [] A;
   Solution sol=new Solution();
        Scanner my_scan=new Scanner(System.in);
        System.out.println("Veuillez saisir le nombre de compteurs N :");
        int N=my_scan.nextInt();
        while(N<=0 || N>100000)
        { System.out.println("Erreur !\n N doit etre entre [1..100000]");
            N=my_scan.nextInt();       
        }
        System.out.println("Veuillez saisir la taille de votre tableau A :");
        int M=my_scan.nextInt();
         while(M<=0 || M>100000)
        { System.out.println("Erreur !\n M doit etre entre [1..100000]");
            M=my_scan.nextInt();       
        }
        
        A=new int [M];
        for (int i=0;i<M;i++)
        {System.out.println("A["+(i+1)+"]:");
         A[i]=my_scan.nextInt();
                while (A[i]<1 || A[i]>(N+1)) 
                {System.out.println("Erreur !\n A[i] doit être entre [1..N+1]");
                    A[i]=my_scan.nextInt();
                }
        }
        int []res=sol.solution(N, A);

            System.out.print("[");
        
        for (int i=0;i<N;i++)
        {if (i<N-1)
            System.out.print(res[i]+",");
        else System.out.print(res[i]);
        }
        System.out.print("]");
    }
    
}
