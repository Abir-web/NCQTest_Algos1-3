/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algo1;

/**
 *
 * @author hp
 */
public class Solution {
  public int[] solution(int N, int[] A){
      int M=A.length;
       int i=0;
      int [] tabCounters=new int[N];
                
        for (i=0;i<N;i++)//initialiser le tableau des compteurs à 0
            tabCounters[i]=0;
        
        for (int k=0;k<M;k++)
            {if (A[k]<=N && A[k]>=1)
                tabCounters[A[k]-1]++;
             else 
                if (A[k]==(N+1))
                    { int max=0;
                        for (int j=0;j<N;j++)//on va chercher le maximum des compteurs et l'affecter à la variable max
                        {if (tabCounters[j]>max)
                            max=tabCounters[j];                                           
                        }
                        for (int j=0;j<N;j++)//on va affecter la variable max à tous les compteurs 
                            tabCounters[j]=max;                                           

                    }

            }

  
        return tabCounters;//si ce traitement n'est pas effectué (on a un problème au niveau du contrôle de saisie) alors il va retourner un tableau vide
      }
  }
