/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algo3;

import java.util.Scanner;

/**
 *
 * @author hp
 */
public class Algo3 {

    public static void main(String[] args) {
         int [] A;
   Solution sol=new Solution();
        Scanner my_scan=new Scanner(System.in);
        System.out.println("Veuillez saisir la taille N du tableau A:");
        int N=my_scan.nextInt();
        while(N<=0 || N>100000)
        { System.out.println("Erreur !\n N doit etre entre [1..20000]");
            N=my_scan.nextInt();       
        }
        A=new int [N];
        for (int i=0;i<N;i++)
        {System.out.println("A["+(i+1)+"]:");
         A[i]=my_scan.nextInt();
                while (A[i]<-100 || A[i]>100) 
                {System.out.println("Erreur !\n A[i] doit être entre [-100..100]");
                    A[i]=my_scan.nextInt();
                }
        }
        int res=sol.solution(A);

        System.out.println("Val(A,S)= "+res);
    
    }
    
}
