/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algo3;

/**
 *
 * @author hp
 */
public class Solution {
   public int solution(int[] A){
    int [] S1=new int[A.length];
    int [] S2=new int[A.length];
    int val1=0,val2=0;
        for (int i=0;i<A.length;i=i+2)
        {
            S1[i]=-1;
            S2[i]=1;
        }
        for (int i=1;i<A.length;i=i+2)
        {
            S1[i]=1;
            S2[i]=-1;
        }
        for (int i=0;i<A.length;i++)
        {
            val1=val1+(S1[i]*A[i]);           
            val2=val2+(S2[i]*A[i]);
        }
        if (val1<val2)
            return val1;
        else return val2;
    }
    
}
